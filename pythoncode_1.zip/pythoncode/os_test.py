# -*- coding: utf-8 -*-
"""
Created on Tue Jul  4 09:45:45 2017

@author: 29907
"""

import os

cwd=os.getcwd()
l=os.path.isabs(cwd)
