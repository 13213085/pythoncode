cats={';Hary': 2, 'Kate': 3}
